// Descripción: Fragmento para seleccionar comida en el configurador de pedido de comida.
// Autor: Edwin Eduardo Ccama Pari
// Fecha de creación: 26/04/2025
// Fecha última modificación: 26/04/2025


package com.example.pedidocomidaapp

import android.os.Bundle
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController

@Composable
fun SeleccionComidaScreen(navController: NavController) {
    var comidaSeleccionada by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Selecciona tu comida favorita")

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = { comidaSeleccionada = "Pizza" }) {
            Text("Pizza")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { comidaSeleccionada = "Hamburguesa" }) {
            Text("Hamburguesa")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { comidaSeleccionada = "Ensalada" }) {
            Text("Ensalada")
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                if (comidaSeleccionada.isNotEmpty()) {
                    // Pasamos la comida seleccionada a la siguiente pantalla
                    navController.navigate("seleccionExtras/$comidaSeleccionada")
                } else {
                    Toast.makeText(LocalContext.current, "Selecciona una comida", Toast.LENGTH_SHORT).show()
                }
            }
        ) {
            Text(text = "Siguiente")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SeleccionComidaScreenPreview() {
    PedidoComidaAppTheme {
        SeleccionComidaScreen(navController = rememberNavController())
    }
}

