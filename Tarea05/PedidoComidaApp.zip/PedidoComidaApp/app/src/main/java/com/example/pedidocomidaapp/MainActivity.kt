// Descripción: Configurador de pedido de comida
// Autor: Edwin Edaurdo Ccama Pari
// Fecha de creación: 26/04/2025
// Fecha última modificación: 26/04/2025

package com.example.pedidocomidaapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.pedidocomidaapp.ui.theme.PedidoComidaAppTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            PedidoComidaAppTheme {
                val navController: NavHostController = rememberNavController()

                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    NavHost(
                        navController = navController,
                        startDestination = "inicio",
                        modifier = Modifier.padding(innerPadding)
                    ) {
                        composable("inicio") {
                            InicioScreen(navController)
                        }
                        composable("seleccionComida") {
                            SeleccionComidaScreen(navController)
                        }
                        composable("seleccionExtras/{comida}") { backStackEntry ->
                            val comida = backStackEntry.arguments?.getString("comida") ?: ""
                            SeleccionExtrasScreen(navController, comida)
                        }
                        composable("resumenPedido/{comida}/{extras}") { backStackEntry ->
                            val comida = backStackEntry.arguments?.getString("comida") ?: ""
                            val extras = backStackEntry.arguments?.getString("extras") ?: ""
                            ResumenPedidoScreen(navController, comida, extras)
                        }
                    }
                }
            }
        }
    }
}

