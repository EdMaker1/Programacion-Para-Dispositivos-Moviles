// Descripción: Fragmento para mostrar el resumen del pedido y permitir confirmar o editar.
// Autor: Edwin Eduardo Ccama Pari
// Fecha de creación: 26/04/2025
// Fecha última modificación: 26/04/2025

package com.example.pedidocomidaapp

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun ResumenPedidoScreen(navController: NavController, comida: String, extras: String) {
    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Resumen del Pedido")

        Spacer(modifier = Modifier.height(16.dp))

        Text(text = "Comida: $comida")
        Text(text = "Extras: $extras")

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                // Muestra un toast de confirmación
                Toast.makeText(context, "Pedido confirmado: $comida + $extras", Toast.LENGTH_SHORT).show()
                navController.navigate("inicio") {
                    popUpTo("inicio") { inclusive = true }
                }
            }
        ) {
            Text(text = "Confirmar Pedido")
        }

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            onClick = {
                // Pasamos el resultado de la edición de pedido usando setFragmentResult
                navController.previousBackStackEntry?.let { backStackEntry ->
                    val result = Bundle().apply {
                        putString("comida", comida)
                        putString("extras", extras)
                    }
                    backStackEntry.savedStateHandle.set("editResult", result)
                }
                navController.popBackStack("seleccionComida", inclusive = false)
            }
        ) {
            Text(text = "Editar Pedido")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ResumenPedidoScreenPreview() {
    PedidoComidaAppTheme {
        ResumenPedidoScreen(navController = rememberNavController(), comida = "Pizza", extras = "Bebida")
    }
}
