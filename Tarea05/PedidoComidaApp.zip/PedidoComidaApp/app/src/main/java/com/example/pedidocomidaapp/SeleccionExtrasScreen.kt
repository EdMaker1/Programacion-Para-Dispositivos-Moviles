// Descripción: Fragmento para seleccionar los extras en el configurador de pedido de comida.
// Autor: // Autor: Edwin Eduardo Ccama Pari
// Fecha de creación: 26/04/2025
// Fecha última modificación: 26/04/2025

package com.example.pedidocomidaapp

import android.os.Bundle
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController

@Composable
fun SeleccionExtrasScreen(navController: NavController, comida: String) {
    var extrasSeleccionados by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "Selecciona tus extras")

        Spacer(modifier = Modifier.height(32.dp))

        Button(onClick = { extrasSeleccionados = "Bebida" }) {
            Text("Bebida")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { extrasSeleccionados = "Papas" }) {
            Text("Papas")
        }
        Spacer(modifier = Modifier.height(8.dp))
        Button(onClick = { extrasSeleccionados = "Postre" }) {
            Text("Postre")
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = {
                if (extrasSeleccionados.isNotEmpty()) {
                    navController.navigate("resumenPedido/$comida/$extrasSeleccionados")
                } else {
                    Toast.makeText(LocalContext.current, "Selecciona un extra", Toast.LENGTH_SHORT).show()
                }
            }
        ) {
            Text(text = "Siguiente")
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SeleccionExtrasScreenPreview() {
    PedidoComidaAppTheme {
        SeleccionExtrasScreen(navController = rememberNavController(), comida = "Pizza")
    }
}
