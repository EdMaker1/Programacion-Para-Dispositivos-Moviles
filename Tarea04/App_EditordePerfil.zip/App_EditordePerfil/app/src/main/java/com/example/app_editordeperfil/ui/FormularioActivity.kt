package com.example.app_editordeperfil.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.app_editordeperfil.Usuario
import com.example.app_editordeperfil.databinding.ActivityFormularioBinding

class FormularioActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFormularioBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFormularioBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnContinuar.setOnClickListener {
            val nombre = binding.etNombre.text.toString()
            val edad = binding.etEdad.text.toString()
            val ciudad = binding.etCiudad.text.toString()
            val correo = binding.etCorreo.text.toString()

            val usuario = Usuario(nombre, edad, ciudad, correo)

            val intent = Intent(this, ResumenActivity::class.java)
            intent.putExtra("usuario", usuario)
            startActivityForResult(intent, 1)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == 1) {
            if (resultCode == Activity.RESULT_OK) {
                // Mostrar Toast cuando vuelva con Confirmar
                Toast.makeText(this, "Perfil guardado correctamente", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
