// Descripción: Pantalla de resumen de datos del usuario
// Autor: [Edwin Eduardo Ccama Pari]
// Fecha de creación: [25-04-2025]
// Última modificación: [26-04-2025]

package com.tu_paquete.ui  // <-- Ajusta según tu paquete real

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.tu_paquete.R  // <-- Ajusta también aquí
import com.tu_paquete.Usuario  // <-- Ajusta según donde esté tu data class

class ResumenActivity : AppCompatActivity() {

    private lateinit var usuario: Usuario

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_resumen)

        // 1. Recuperar el usuario que viene de FormularioActivity
        usuario = intent.getParcelableExtra<Usuario>("usuario")!!

        // 2. Mostrar los datos en TextViews
        findViewById<TextView>(R.id.tvNombre).text = "Nombre: ${usuario.nombre}"
        findViewById<TextView>(R.id.tvEdad).text = "Edad: ${usuario.edad}"
        findViewById<TextView>(R.id.tvCiudad).text = "Ciudad: ${usuario.ciudad}"
        findViewById<TextView>(R.id.tvCorreo).text = "Correo: ${usuario.correo}"

        // 3. Botón Confirmar
        findViewById<Button>(R.id.btnConfirmar).setOnClickListener {
            // Devolver resultado "Perfil guardado correctamente"
            val intent = Intent()
            intent.putExtra("mensaje", "Perfil guardado correctamente")
            setResult(Activity.RESULT_OK, intent)
            finish()
        }

        // 4. Botón Volver a editar
        findViewById<Button>(R.id.btnVolverEditar).setOnClickListener {
            setResult(Activity.RESULT_CANCELED)
            finish()
        }
    }
}
